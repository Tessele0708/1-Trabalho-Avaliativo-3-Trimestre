import re
from datetime import date
from decimal import Decimal, InvalidOperation

from flask import Blueprint, flash, redirect, render_template, request, url_for
from sqlalchemy.exc import IntegrityError

from extensions import db
from models import Abrigo, Animal, FichaSaude, Voluntario

bp = Blueprint('main', __name__)


def email_ok(value):
    return bool(re.fullmatch(r"[^\s@]+@[^\s@]+\.[^\s@]+", value or ''))


def save_or_error(action, success, endpoint):
    try:
        action()
        db.session.commit()
        flash(success, 'success')
        return redirect(url_for(endpoint))
    except IntegrityError:
        db.session.rollback()
        flash('Não foi possível salvar: confira os campos únicos e os vínculos existentes.', 'danger')
    except Exception:
        db.session.rollback()
        flash('Não foi possível concluir a operação. Confira os dados e tente novamente.', 'danger')
    return None


@bp.route('/')
def index():
    return render_template('index.html', abrigos=Abrigo.query.count(), animais=Animal.query.count(), voluntarios=Voluntario.query.count())


@bp.route('/abrigos')
def abrigos():
    return render_template('abrigos.html', items=Abrigo.query.order_by(Abrigo.nome).all())


@bp.route('/abrigos/novo', methods=['GET', 'POST'])
@bp.route('/abrigos/<int:item_id>/editar', methods=['GET', 'POST'])
def abrigo_form(item_id=None):
    item = db.session.get(Abrigo, item_id) if item_id else Abrigo()
    if item_id and not item:
        flash('Abrigo não encontrado.', 'warning'); return redirect(url_for('main.abrigos'))
    if request.method == 'POST':
        nome, cidade, email, telefone = (request.form.get(k, '').strip() for k in ('nome', 'cidade', 'email', 'telefone'))
        if not all((nome, cidade, email, telefone)) or not email_ok(email):
            flash('Preencha todos os campos. Informe um e-mail válido.', 'danger')
        else:
            item.nome, item.cidade, item.email, item.telefone = nome, cidade, email.lower(), telefone
            if not item_id: db.session.add(item)
            response = save_or_error(lambda: None, 'Abrigo salvo com sucesso!', 'main.abrigos')
            if response: return response
    return render_template('form.html', title='Abrigo', item=item, fields=[('nome','Nome','text',True),('cidade','Cidade','text',True),('email','E-mail','email',True),('telefone','Telefone','tel',True)])


@bp.post('/abrigos/<int:item_id>/excluir')
def abrigo_delete(item_id):
    item = db.session.get(Abrigo, item_id)
    if not item: flash('Abrigo não encontrado.', 'warning')
    elif item.animais: flash('Este abrigo ainda tem animais. Transfira-os antes de excluir.', 'warning')
    else:
        response = save_or_error(lambda: db.session.delete(item), 'Abrigo excluído.', 'main.abrigos')
        if response: return response
    return redirect(url_for('main.abrigos'))


@bp.route('/voluntarios')
def voluntarios():
    return render_template('voluntarios.html', items=Voluntario.query.order_by(Voluntario.nome).all())


@bp.route('/voluntarios/novo', methods=['GET','POST'])
@bp.route('/voluntarios/<int:item_id>/editar', methods=['GET','POST'])
def voluntario_form(item_id=None):
    item = db.session.get(Voluntario, item_id) if item_id else Voluntario()
    if item_id and not item: flash('Voluntário não encontrado.','warning'); return redirect(url_for('main.voluntarios'))
    if request.method == 'POST':
        nome, email, telefone = (request.form.get(k,'').strip() for k in ('nome','email','telefone'))
        if not all((nome,email,telefone)) or not email_ok(email): flash('Preencha os campos e informe um e-mail válido.','danger')
        else:
            item.nome,item.email,item.telefone=nome,email.lower(),telefone
            if not item_id: db.session.add(item)
            response=save_or_error(lambda:None,'Voluntário salvo com sucesso!','main.voluntarios')
            if response:return response
    return render_template('form.html',title='Voluntário',item=item,fields=[('nome','Nome','text',True),('email','E-mail','email',True),('telefone','Telefone','tel',True)])


@bp.post('/voluntarios/<int:item_id>/excluir')
def voluntario_delete(item_id):
    item=db.session.get(Voluntario,item_id)
    if not item: flash('Voluntário não encontrado.','warning')
    else:
        item.animais.clear()
        response=save_or_error(lambda:db.session.delete(item),'Voluntário excluído.','main.voluntarios')
        if response:return response
    return redirect(url_for('main.voluntarios'))


@bp.route('/animais')
def animais():
    return render_template('animais.html',items=Animal.query.order_by(Animal.nome).all())


@bp.route('/animais/novo', methods=['GET','POST'])
@bp.route('/animais/<int:item_id>/editar', methods=['GET','POST'])
def animal_form(item_id=None):
    item=db.session.get(Animal,item_id) if item_id else Animal()
    if item_id and not item: flash('Animal não encontrado.','warning'); return redirect(url_for('main.animais'))
    abrigos=Abrigo.query.order_by(Abrigo.nome).all(); voluntarios=Voluntario.query.order_by(Voluntario.nome).all()
    if request.method=='POST':
        nome=request.form.get('nome','').strip(); especie=request.form.get('especie','').strip(); raca=request.form.get('raca','').strip()
        sexo=request.form.get('sexo',''); abrigo=db.session.get(Abrigo,request.form.get('abrigo_id',type=int))
        nascimento=request.form.get('data_nascimento','').strip()
        try: nascimento=date.fromisoformat(nascimento) if nascimento else None
        except ValueError: nascimento='invalid'
        selected=Voluntario.query.filter(Voluntario.id.in_(request.form.getlist('voluntarios',type=int))).all()
        if not nome or not especie or sexo not in ('Fêmea','Macho','Não informado') or not abrigo or nascimento=='invalid': flash('Confira os campos obrigatórios e a data de nascimento.','danger')
        else:
            item.nome,item.especie,item.raca,item.sexo,item.data_nascimento,item.abrigo=nome,especie,raca or None,sexo,nascimento,abrigo
            item.adotado=request.form.get('adotado')=='sim'; item.voluntarios=selected
            if not item_id: db.session.add(item)
            response=save_or_error(lambda:None,'Animal salvo com sucesso!','main.animais')
            if response:return response
    return render_template('animal_form.html',item=item,abrigos=abrigos,voluntarios=voluntarios)


@bp.post('/animais/<int:item_id>/excluir')
def animal_delete(item_id):
    item=db.session.get(Animal,item_id)
    if not item: flash('Animal não encontrado.','warning')
    else:
        response=save_or_error(lambda:db.session.delete(item),'Animal e ficha de saúde excluídos.','main.animais')
        if response:return response
    return redirect(url_for('main.animais'))


@bp.route('/animais/<int:animal_id>/ficha', methods=['GET','POST'])
def ficha_form(animal_id):
    animal=db.session.get(Animal,animal_id)
    if not animal: flash('Animal não encontrado.','warning'); return redirect(url_for('main.animais'))
    is_new = animal.ficha is None
    item = FichaSaude() if is_new else animal.ficha
    if request.method=='POST':
        vacinas=request.form.get('vacinas','').strip(); observacoes=request.form.get('observacoes','').strip()
        try: peso=Decimal(request.form.get('peso_kg',''))
        except (InvalidOperation, TypeError): peso=Decimal('0')
        if not vacinas or peso<=0 or peso>999: flash('Informe as vacinas e um peso válido maior que zero.','danger')
        else:
            item.vacinas,item.peso_kg,item.observacoes=vacinas,peso,observacoes or None
            item.castrado=request.form.get('castrado')=='sim'
            if is_new:
                db.session.add(item)
                item.animal = animal
            response=save_or_error(lambda:None,'Ficha de saúde salva!','main.animais')
            if response:return response
    return render_template('ficha_form.html',animal=animal,item=item)


@bp.route('/abrigos/<int:item_id>/animais')
def abrigo_animais(item_id):
    item=db.session.get(Abrigo,item_id)
    if not item: flash('Abrigo não encontrado.','warning'); return redirect(url_for('main.abrigos'))
    return render_template('animais.html',items=item.animais,title=f'Animais de {item.nome}')
