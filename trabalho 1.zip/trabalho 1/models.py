from extensions import db

animal_voluntario = db.Table(
    'animal_voluntario',
    db.Column('animal_id', db.Integer, db.ForeignKey('animais.id', ondelete='CASCADE'), primary_key=True),
    db.Column('voluntario_id', db.Integer, db.ForeignKey('voluntarios.id', ondelete='CASCADE'), primary_key=True),
)


class Abrigo(db.Model):
    __tablename__ = 'abrigos'
    id = db.Column(db.Integer, primary_key=True)
    nome = db.Column(db.String(100), nullable=False, unique=True)
    cidade = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(120), nullable=False, unique=True)
    telefone = db.Column(db.String(30), nullable=False)
    animais = db.relationship('Animal', back_populates='abrigo', passive_deletes=True)


class Animal(db.Model):
    __tablename__ = 'animais'
    id = db.Column(db.Integer, primary_key=True)
    nome = db.Column(db.String(80), nullable=False)
    especie = db.Column(db.String(50), nullable=False)
    raca = db.Column(db.String(80), nullable=True)
    sexo = db.Column(db.String(20), nullable=False)
    data_nascimento = db.Column(db.Date, nullable=True)
    adotado = db.Column(db.Boolean, nullable=False, default=False)
    abrigo_id = db.Column(db.Integer, db.ForeignKey('abrigos.id', ondelete='RESTRICT'), nullable=False)
    abrigo = db.relationship('Abrigo', back_populates='animais')
    voluntarios = db.relationship('Voluntario', secondary=animal_voluntario, back_populates='animais')
    ficha = db.relationship('FichaSaude', back_populates='animal', uselist=False, cascade='all, delete-orphan')


class Voluntario(db.Model):
    __tablename__ = 'voluntarios'
    id = db.Column(db.Integer, primary_key=True)
    nome = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(120), nullable=False, unique=True)
    telefone = db.Column(db.String(30), nullable=False)
    animais = db.relationship('Animal', secondary=animal_voluntario, back_populates='voluntarios')


class FichaSaude(db.Model):
    __tablename__ = 'fichas_saude'
    id = db.Column(db.Integer, primary_key=True)
    vacinas = db.Column(db.Text, nullable=False)
    castrado = db.Column(db.Boolean, nullable=False, default=False)
    peso_kg = db.Column(db.Numeric(5, 2), nullable=False)
    observacoes = db.Column(db.Text, nullable=True)
    animal_id = db.Column(db.Integer, db.ForeignKey('animais.id', ondelete='CASCADE'), nullable=False, unique=True)
    animal = db.relationship('Animal', back_populates='ficha')
