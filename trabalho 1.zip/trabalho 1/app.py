import os

from dotenv import load_dotenv
from flask import Flask
from flask_migrate import Migrate

from extensions import db
from routes import bp

load_dotenv()


def create_app():
    app = Flask(__name__)
    app.config.from_mapping(
        SECRET_KEY=os.environ.get('SECRET_KEY', 'desenvolvimento-local'),
        SQLALCHEMY_DATABASE_URI=os.environ.get('DATABASE_URL', ''),
        SQLALCHEMY_TRACK_MODIFICATIONS=False,
    )
    db.init_app(app)
    Migrate(app, db)
    app.register_blueprint(bp)
    return app


app = create_app()

if __name__ == '__main__':
    app.run(debug=True)
